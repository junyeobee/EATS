package com.eats.store.service;

public interface StoreLoginService {

	public int storeLogin(String storeId, String storePwd);
	
	
}
