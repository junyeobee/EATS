package com.eats.mapper.store;

public interface StoreMapper {

	public String storeLogin(String storeId);
	
}
